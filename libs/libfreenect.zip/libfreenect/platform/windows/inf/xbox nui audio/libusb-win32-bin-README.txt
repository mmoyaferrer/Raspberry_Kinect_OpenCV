libusb-win32-bin v1.2.2.0 (10/02/2010) - [Package Information]

ALL ARCHITECTURES:
  x86\libusb0_x86.dll: x86 32-bit library. Must be renamed to libusb0.dll
    On 64 bit, Installs to Windows\syswow64\libusb0.dll.
    On 32 bit, Installs to Windows\system32\libusb0.dll.

  x86\inf-wizard.exe: inf-wizard application with embedded libusb-win32
    v1.2.2.0 binaries.

X86 ONLY ARCHITECTURES:
  x86\libusb0.sys: x86 32-bit driver.
    Installs to Windows\system32\drivers\libusb0.sys

AMD64-INTEL64 ONLY ARCHITECTURES:
  amd64\libusb0.sys: x64 64-bit driver.
    Installs to Windows\system32\drivers\libusb0.sys

  amd64\libusb0.dll: x64 64-bit library.
    Installs to Windows\system32\libusb0.dll

IA64 ONLY ARCHITECTURES:
  ia64\libusb0.sys: IA64 64-bit driver.
    Installs to Windows\system32\drivers\libusb0.sys

  ia64\libusb0.dll: IA64 64-bit library.
    Installs to Windows\system32\libusb0.dll
